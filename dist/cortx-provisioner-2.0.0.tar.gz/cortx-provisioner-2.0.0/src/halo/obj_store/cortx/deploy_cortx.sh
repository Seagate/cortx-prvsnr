#!/bin/bash -x
#
# Copyright (c) 2021 Seagate Technology LLC and/or its Affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# For any questions about this software or licensing,
# please email opensource@seagate.com or cortx-questions@seagate.com.
#

cd /root/cortx-k8s/k8_cortx_cloud;./destroy-cortx-cloud.sh
pip3 show yq && pip3 uninstall yq -y
YQ_VERSION=v4.25.1
YQ_BINARY=yq_linux_386
wget https://github.com/mikefarah/yq/releases/download/${YQ_VERSION}/${YQ_BINARY}.tar.gz -O - | tar xz && mv ${YQ_BINARY} /usr/bin/yq
if [ -f /usr/local/bin/yq ]; then rm -rf /usr/local/bin/yq; fi
cd /root/cortx-k8s/k8_cortx_cloud;./deploy-cortx-cloud.sh
